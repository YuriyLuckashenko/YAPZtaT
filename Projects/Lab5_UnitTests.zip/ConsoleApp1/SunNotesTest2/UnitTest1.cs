﻿using System;
using System.Collections.Generic;
using ConsoleApp1;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SunNotesTest2
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Test_IsParametersNote_Null_True()
        {
            //налаштування          
            Note test = new Note();
            test.Num = 1;
            test.Title = null;
            test.Text = "Текст нотатки. Більше одного речення. А може двох. Навіть трьох.";
            test.Tags = "Тег1 тег2";
            test.Color = "FFAAFF";
            test.Datatime = DateTime.Now;
            bool expected = true;

            //дії
            User us = new User();
            bool actual = us.IsParametersNoteNull(test);

            //перевірка
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Test_IsParametersNote_Null_False()
        {
            //налаштування          
            Note test = new Note();
            test.Num = 2;
            test.Title = "Назва нотатки";
            test.Text = "Текст нотатки. Більше одного речення. А може двох. Навіть трьох.";
            test.Tags = "Тег1 тег2";
            test.Color = "FFAAFF";
            test.Datatime = DateTime.Now;
            bool expected = false;

            //дії
            User us = new User();
            bool actual = us.IsParametersNoteNull(test);

            //перевірка
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Test_FindDate_True()
        {
            //налаштування  
            List<Note> lst = new List<Note>();
            Note test1 = new Note();
            test1.Datatime = DateTime.Today;
            lst.Add(test1);

            Note test2 = new Note();
            test2.Datatime = DateTime.MaxValue;
            lst.Add(test2);

            bool expected = true;

            //дії
            User us = new User(lst);
            bool actual = us.FindDate(DateTime.Now);

            //перевірка
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Test_FindDate_False()
        {
            //налаштування  
            List<Note> lst = new List<Note>();
            Note test1 = new Note();
            test1.Datatime = DateTime.MinValue;
            lst.Add(test1);

            Note test2 = new Note();
            test2.Datatime = DateTime.MaxValue;
            lst.Add(test2);

            bool expected = false;

            //дії
            User us = new User(lst);
            bool actual = us.FindDate(DateTime.Now);

            //перевірка
            Assert.AreEqual(expected, actual);
        }
    }
}
