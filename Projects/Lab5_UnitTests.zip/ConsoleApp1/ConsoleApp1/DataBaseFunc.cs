﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class DataBaseFunc
    {
        string connect = "Data Source = (LocalDB)\\MSSQLLocalDB; AttachDbFilename = D:\\2017\\5 семестр\\ПППИ\\ConsoleApp1\\ConsoleApp1\\ConsoleApp1\\SunNotes.mdf; Integrated Security = True";


        public void insertNote(Note note)
        {
            using (SqlConnection con = new SqlConnection(connect))
            {
                String query = "INSERT INTO [Notte] (Title, Text, Tags, Color, Date) VALUES (@Title, @Text, @Tags, @Color, @Date)";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@Title", SqlDbType.NVarChar).Value = note.Title;
                    cmd.Parameters.AddWithValue("@Text", SqlDbType.Text).Value = note.Text;
                    cmd.Parameters.AddWithValue("@Tags", SqlDbType.NVarChar).Value = note.Tags;
                    cmd.Parameters.AddWithValue("@Color", SqlDbType.NVarChar).Value = note.Color;
                    cmd.Parameters.AddWithValue("@Date", SqlDbType.Date).Value = note.Datatime.Date;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
        }

        public void selectAllNotes(List<Note> all)
        {
            using (SqlConnection con = new SqlConnection(connect))
            {
                string query = "SELECT * FROM [Notte]";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    SqlDataReader read = cmd.ExecuteReader();
                    while (read.Read())
                    {
                        Note note = new Note();
                        note.Num = all.Count;
                        note.Title = read["Title"].ToString();
                        note.Text = read["Text"].ToString();
                        note.Tags = read["Tags"].ToString();
                        note.Color = read["Color"].ToString();
                        note.Datatime = Convert.ToDateTime(read["Date"]);
                        all.Add(note);
                    }
                    read.Close();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
        }

        public void selectOnDate(List<Note> all, DateTime dt)
        {
            using (SqlConnection con = new SqlConnection(connect))
            {
                string query = "SELECT * FROM [Notte] WHERE [Notte].Date = " + "@NoteDate";
                using (SqlCommand cmd = new SqlCommand(query, con))
                { 
                    cmd.Parameters.Add("@NoteDate", SqlDbType.Date).Value = dt.ToShortDateString();
                    con.Open();
                    SqlDataReader read = cmd.ExecuteReader();
                    while (read.Read())
                    {
                        Note note = new Note();
                        note.Num = all.Count;
                        note.Title = read["Title"].ToString();
                        note.Text = read["Text"].ToString();
                        note.Tags = read["Tags"].ToString();
                        note.Color = read["Color"].ToString();
                        note.Datatime = Convert.ToDateTime(read["Date"]);
                        all.Add(note);
                        note.ShowNote();
                    }
                    read.Close();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
        }

        public void deleteAllNotesFromBase()
        {
            using (SqlConnection con = new SqlConnection(connect))
            {
                String query = "TRUNCATE TABLE [Notte]";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
        }
    }
}
