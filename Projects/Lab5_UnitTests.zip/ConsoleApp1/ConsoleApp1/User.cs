﻿using System;
using System.Reflection;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class User
    {
        List<Note> list_of_notes;
        private string name;
        private string password;
        private string checkpassw;

        public User()
        {
            List_of_notes = null;
        }

        public User(List<Note> list_of_notes)
        {
            List_of_notes = list_of_notes;
        }

        public List<Note> List_of_notes { get => list_of_notes; set => list_of_notes = value; }
        public string Name { get => name; set => name = value; }
        public string Password { get => password; set => password = value; }
        public string Checkpassw { get => checkpassw; set => checkpassw = value; }

        public bool FindDate(DateTime DT)
        {
            bool finded = false;
            foreach (Note note in list_of_notes)
            {
                if (DT.Date == note.Datatime.Date)
                {
                    Console.WriteLine("=====================================================");
                    Console.WriteLine("Найдена заметка за {0}", DT.Date.ToShortDateString());
                    Console.WriteLine("=====================================================");
                    finded = true;
                    note.ShowNote();
                } 
            }
            if (finded == true) return finded; else return false;
        }

        public bool IsParametersNoteNull(Note n)
        {
            foreach (PropertyInfo pi in n.GetType().GetProperties())
            {
                if (pi.PropertyType == typeof(string))
                {
                    string value = (string)pi.GetValue(n);
                    if (string.IsNullOrEmpty(value))
                    {
                        return true;
                    }
                }
            }
            return false;
        }
    }
}
