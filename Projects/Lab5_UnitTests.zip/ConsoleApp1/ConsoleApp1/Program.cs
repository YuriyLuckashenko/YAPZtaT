﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Arch_Unarch au = new Arch_Unarch();
            DataBaseFunc dbf = new DataBaseFunc();
            int choose, testnum;
            long num = 0;
            string title;
            string text;
            string tag;
            string color;
            //List<string> tags = new List<string>();
            DateTime datetime = new DateTime();
           
            List<Note> list_of_notes = new List<Note>();
            User user = new User(list_of_notes);
            Console.WriteLine("Программа Sun Notes. Консольная версия. \r\nВыбор дейcтвия:");
            Console.WriteLine("1 - Добавить заметку");
            Console.WriteLine("2 - Показать заметку");
            Console.WriteLine("3 - Заметки по дате");
            Console.WriteLine("4 - Заархивировать");
            Console.WriteLine("5 - Разархивировать");
            Console.WriteLine("6 - Добавить заметку в базу данных");
            Console.WriteLine("7 - Извлечь все заметки из базы данных в программу");
            Console.WriteLine("8 - Удалить все заметки из базы данных");
            Console.WriteLine("9 - Ивлечь заметки по указанной дате");
            Console.WriteLine("0 - Выход.");
            choose = Convert.ToInt32(Console.ReadLine());
            while(choose!=0)
            {
                switch (choose)
                {
                    case 1:
                        Note current = new Note();
                        num = list_of_notes.Count;
                        Console.WriteLine("Введите название заметки:");
                        title = Console.ReadLine();
                        Console.WriteLine("Введите текст заметки:");
                        text = Console.ReadLine();
                        Console.WriteLine("Введите теги заметки:");
                        tag = Console.ReadLine(); 
                        datetime = DateTime.Now;
                        //while (tag != "")
                        //{
                        //    current.addTags(tag);
                        //    tag = Console.ReadLine();
                        //}
                        Console.WriteLine("Введите цвет заметки:");
                        Console.Write("#");
                        color = Console.ReadLine();
                        current.Num = num;
                        current.Title = title;
                        current.Text = text;
                        current.Datatime = datetime;
                        current.Color = color;
                        current.Tags = tag;
                        //User u = new User(list_of_notes);
                        //Console.WriteLine(u.IsParametersNoteNull(current).ToString());
                        list_of_notes.Add(current);
                        current = null;

                        break;
                    case 2:
                        Console.WriteLine("Введите номер заметки:");
                        testnum = Convert.ToInt32(Console.ReadLine());
                        list_of_notes[testnum].ShowNote();
                        //foreach (Note n in list_of_notes)
                        //{
                        //    if (n.Num == testnum)
                        //        n.ShowNote();
                        //}
                        break;
                    case 3:
                        user.List_of_notes = list_of_notes;
                        Console.WriteLine("Введите дату(YYYY-MM-DD):");
                        datetime = Convert.ToDateTime(Console.ReadLine()).Date;
                        user.FindDate(datetime);
                        break;
                    case 4:  
                        au.Arch(list_of_notes);
                        break;
                    case 5:
                        au.UnArch(list_of_notes);
                        break;
                    case 6:
                        dbf.insertNote(list_of_notes.Last());
                        Console.WriteLine("Заметка успешно добавлена");
                        break;
                    case 7:
                        dbf.selectAllNotes(list_of_notes);
                        Console.WriteLine("Данные успешно считаны");
                        break;
                    case 8:
                        dbf.deleteAllNotesFromBase();
                        Console.WriteLine("Данные успешно удалены");
                        break;
                    case 9:
                        Console.WriteLine("Введите дату(YYYY-MM-DD):");
                        datetime = Convert.ToDateTime(Console.ReadLine());
                        dbf.selectOnDate(list_of_notes,datetime);
                        break;

                }
                Console.WriteLine("Выбор дейcтвия:");
                choose = Convert.ToInt32(Console.ReadLine());            
            }
            Console.ReadKey();
        }
    }
}
