﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ionic.Zip;
using Newtonsoft.Json;
using System.IO;

namespace ConsoleApp1
{
    public class Arch_Unarch
    {
        //Ionic.Zip.FolderBrowserDialog bd = new FolderBrowserDialog();
        private string path;

        public Arch_Unarch() { }
        void fromclasstojson(Note N)
        {
            string json = JsonConvert.SerializeObject(N);
            File.WriteAllText(@"D:\PPPI\" + N.Num + ".json", json);
        }

        void fromjsontoclass(string path, List<Note> list_of_notes)
        {
            string json = File.ReadAllText(path);
            int num = list_of_notes.Count;
            Note jnote = new Note();
            jnote = JsonConvert.DeserializeObject<Note>(json);
            jnote.Num = num;
            list_of_notes.Add(jnote);
        }

        public void Arch(List<Note> list_of_notes)
        {
            Console.WriteLine("Введите путь куда сохранить архив: ");
            path = Console.ReadLine();
            ZipFile zf = new ZipFile(path);
            foreach (Note note in list_of_notes)
            {
                fromclasstojson(note);
            }
            zf.AddDirectory(@"D:\PPPI");
            zf.Save();
        }

        public void UnArch(List<Note> list_of_notes)
        {
            Console.WriteLine("Введите путь к архиву: ");
            path = Console.ReadLine();
            try
            {
                using (ZipFile zip = ZipFile.Read(path))
                {
                    zip.ExtractAll(@"D:\PPPI\", ExtractExistingFileAction.OverwriteSilently);
                }
            }
            catch
            {
                Console.WriteLine("Ошибка считывания архива ");
            }
            int count = new DirectoryInfo(@"D:\PPPI").GetFiles().Length;
            for(int i=0; i<count; i++)
            {
                fromjsontoclass(@"D:\PPPI\"+ i + ".json", list_of_notes);
            }
        }
        public string Path { get => path; set => path = value; }

    }
}
