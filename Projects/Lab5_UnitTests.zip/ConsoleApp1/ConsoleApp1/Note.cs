﻿using System;
using System.Reflection;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ionic.Zip;

namespace ConsoleApp1
{
    public class Note
    {

        private long num;
        private string title;
        private string text;
        //private List<String> tags;
        private string tags;
        private string color;
        private DateTime datetime;

        public long Num { get => num; set => num = value;}
        public string Text { get => text; set => text = value;}
        public string Title { get => title; set => title = value; }
       
        public DateTime Datatime { get => datetime; set => datetime = value; }
        //public List<string> Tags { get => tags; set => tags = value; }
        public string Tags { get => tags; set => tags = value; }
        public string Color { get => color; set => color = value; }

        public Note()
        {
            num = 0;
            title = null;
            text = null;
            //Tags = new List<string>();
            Tags = null;
            datetime = new DateTime();
            color = null;
        }

        public void ShowNote()
        {
            Console.WriteLine("=====================================================");
            Console.WriteLine("Заметка № {0}: {1} ", num, title);
            Console.WriteLine("Текст заметки: \r\n{0} ", text);
            //Console.WriteLine("Теги заметки ");
            //foreach(string t in Tags)
            //{
            //    if (t == null) break;
            //    Console.WriteLine(t);
            //}
            Console.WriteLine("Теги заметки: {0}", Tags);
            Console.WriteLine("Цвет заметки: #{0}", color);
            Console.WriteLine(datetime.ToShortDateString());
        }


        //public void addTags(String t)
        //{
        //    Tags.Add(t);
        //}
    }
}
