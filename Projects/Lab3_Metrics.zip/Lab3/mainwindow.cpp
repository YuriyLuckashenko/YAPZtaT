#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "qmath.h"
int d, t, D, T, voc, N;

MainWindow :: MainWindow(QWidget * parent) :
    QMainWindow(parent),
    ui(new Ui :: MainWindow)
{
    ui -> setupUi(this);
}

MainWindow :: ~ MainWindow()
{
    delete ui;
}

//кол-во строк кода (source lines of code)
void MainWindow :: on_SLOC_clicked()
{
    QString str = ui -> myTextBox -> toPlainText();
    int n = str.count("\n");
    ui -> label_sloc -> setText(QString::number(n+1));
}

//кол-во пустых строк (blank lines of code)
void MainWindow::on_BLOC_clicked()
{
    QString str=ui->myTextBox->toPlainText();
    int n = str.count("\n\n");
    ui->label_bloc->setText(QString::number(n));
}

//кол-во комментариев (comment lines of code)
void MainWindow::on_CLOC_clicked()
{
    QString str=ui->myTextBox->toPlainText();
    int n = str.count("\n//");
    ui->label_cloc->setText(QString::number(n));
}

//кол-во комментариев и кода (Lines with Both Code and Comments)
void MainWindow::on_CSLOC_clicked()
{
    QString str=ui->myTextBox->toPlainText();
    int n = str.count("\n") - str.count("\n\n");
    ui->label_csloc->setText(QString::number(n));
}

//процент коментариев
void MainWindow::on_PerComment_clicked()
{
    QString str=ui->myTextBox->toPlainText();
    int n = str.count("\n//");
    int k = str.count("\n");
    ui->label_percomment->setText(QString::number(((float)n)/(k+1)*100)+"%");
}

//словарь операндов
void MainWindow::on_VocOperands_clicked()
{
    QString str=ui->myTextBox->toPlainText();
    QString res;
    QStringList cur = str.split("\n");
    for(int i=0; i<cur.size(); i++)
    {
        if(cur[i].startsWith("//") == false)
        {
            res += cur[i];
        }
    }
    QRegExp rx("([\\w\\']+)[->\\s,.;]");
    QStringList list;
    int pos = 0;
    while ((pos = rx.indexIn(res, pos)) != -1)
    {
        list << rx.cap(1);
        pos += rx.matchedLength();
    }
    list.removeDuplicates();
    QString types = "int void string double float new delete include Iterator List const array if else for while MainWindow QWidget QMainWindow Ui QRegExp QStringList QString";
    QStringList ltypes;
    ltypes = types.split(" ");
    QStringList::Iterator itt = ltypes.begin();
    for(int i = list.count()-1; i>= 0; --i)
    {
        const QString& item = list[i];
        itt = ltypes.begin();
        while(itt != ltypes.end())
        {
            if(item == *itt)
            {
               list.removeAt(i);
            }
            ++ itt;
            if((item.toFloat() != 0))
            {
                list.removeAt(i);
            }
        }
    }
    for(int i = list.count()-1; i>= 0; --i)
    {
        const QString& item = list[i];
        if(item == 0)
        {
            list.removeAt(i);
        }
    }

    ui->label_vocoperands->setText(QString::number(list.count()));
    ui->vocoperandsBox->setPlainText(list.join("\n"));
    d = list.count();
}

//словарь операторов
void MainWindow::on_VocOperats_clicked()
{
     QString str=ui->myTextBox->toPlainText();
     QStringList cur = str.split("\n");
     QString res;
     for(int i=0; i<cur.size(); i++)
     {
         if(cur[i].startsWith("//") == false && cur[i].startsWith("\"") == false)
         {
             res += cur[i];
         }
     }
     QStringList list = res.split(" ");
     QString types =
"+ - = += ++ -- * << >> < > != == || && & % <= >= ! ~ | ^ -= *= /= . -> , ? :: new delete int void string double float include new delete Iterator List const array if else for while MainWindow QWidget QMainWindow Ui QRegExp QStringList QString";
     QStringList ltypes;
     QStringList ress;
     list.removeDuplicates();
     ltypes = types.split(" ");
     QStringList::Iterator itt = ltypes.begin();
     for(int i = list.count()-1; i >= 0; --i)
     {
         const QString & item = list[i];
         itt = ltypes.begin();
         while(itt != ltypes.end())
         {
             if(item == *itt)
             {
                 ress << item;
             }
             ++ itt;
         }
     }
     ress.removeDuplicates();
     ui->label_vocoperats->setText(QString::number(ress.count()));
     ui->vocoperatsBox->setPlainText(ress.join("\n"));
     t = ress.count();
}

//общее кол-во операторов

void MainWindow::on_ALLOperats_clicked()
{
    QString str=ui->myTextBox->toPlainText();
    QStringList list = str.split(" ");
    QString types =
"+ - = += ++ -- * << >> < > != == || && & % <= >= ! ~ | ^ -= *= /= . -> , ? :: new delete include int void string double float new delete Iterator List const array if else for while MainWindow QWidget QMainWindow Ui QRegExp QStringList QString";
    QStringList ltypes;
    QStringList ress;
    ltypes = types.split(" ");
    QStringList::Iterator itt = ltypes.begin();
    for(int i = list.count()-1; i >= 0; --i)
    {
        const QString & item = list[i];
        itt = ltypes.begin();
        while(itt != ltypes.end())
        {
            if(item == *itt)
            {
                ress << item;
            }
            ++ itt;
        }
    }
    ui->label_alloperats->setText(QString::number(ress.count()));
    T = ress.count();
}

//общее кол-во операндов
void MainWindow::on_AllOperands_clicked()
{
    QString str=ui->myTextBox->toPlainText();
    QString res;
    QStringList cur = str.split("\n");
    for(int i=0; i<cur.size(); i++)
    {
        if(cur[i].startsWith("//") == false)
        {
            res += cur[i];
        }
    }
    QRegExp rx("([\\w\\']+)[->\\s,.;]");
    QStringList list;
    int pos = 0;
    while ((pos = rx.indexIn(res, pos)) != -1)
    {
        list << rx.cap(1);
        pos += rx.matchedLength();
    }
    QString types = "int void string double float new delete include Iterator List const array if else for while MainWindow QWidget QMainWindow Ui QRegExp QStringList QString";
    QStringList ltypes;
    ltypes = types.split(" ");
    QStringList::Iterator itt = ltypes.begin();
    for(int i = list.count()-1; i>= 0; --i)
    {
        const QString& item = list[i];
        itt = ltypes.begin();
        while(itt != ltypes.end())
        {
            if(item == *itt)
            {
                list.removeAt(i);
            }
            ++ itt;
            if((item.toFloat() != 0))
            {
                list.removeAt(i);
            }
        }
    }
    for(int i = list.count()-1; i>= 0; --i)
    {
        const QString& item = list[i];
        if(item == 0)
        {
            list.removeAt(i);
        }
    }
    ui->label_alloperands->setText(QString::number(list.count()));
    D = list.count();
}

//Цикломатическая сложность
void MainWindow::on_Cyclomatic_clicked()
{
    QString str=ui->myTextBox->toPlainText();
    QStringList list = str.split(QRegExp("(for|while|if)"), QString::SkipEmptyParts);
    int s = list.count()-1;
    ui->label_cyclomatic->setText(QString::number(s));
}

//словарь программы
void MainWindow::on_Voc_clicked()
{
    voc = t + d;
    ui->label_hpvoc->setText(QString::number(voc));
}

//Длина программы
void MainWindow::on_N_clicked()
{
    N = T + D;
    ui->label_hpNlength->setText(QString::number(N));
}

//Объём программы N*log2voc
void MainWindow::on_V_clicked()
{
    float q = N * qLn(voc)/qLn(2);
    ui->label_volume->setText(QString::number(q));
}

//Максимальный уровень вложенности
void MainWindow::on_Nesting_clicked()
{
    QString str=ui->myTextBox->toPlainText();
    int max = 0;
    int cur = 0;
    QStringList res;
    res = str.split(" ");
    for(int i = 0; i<res.size()-1; i++)
    {
        if(res[i].startsWith("if(") || res[i].startsWith("for(") || res[i].startsWith("while(") )
        {
            ++cur;
            if(max < cur)
            {
                if(true)
                {
                    max = cur; //test for max nesting level
                }
            }
        }
        else if (res[i].startsWith("}"))
        {
            if(cur>0)
            {
                cur--;
            }
        }
    }
    ui->label_nesting->setText(QString::number(max));
}
