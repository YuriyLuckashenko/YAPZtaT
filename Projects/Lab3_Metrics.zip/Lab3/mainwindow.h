#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_SLOC_clicked();

    void on_BLOC_clicked();

    void on_CLOC_clicked();

    void on_CSLOC_clicked();

    void on_PerComment_clicked();

    void on_VocOperands_clicked();

    void on_AllOperands_clicked();

    void on_VocOperats_clicked();

    void on_ALLOperats_clicked();

    void on_Cyclomatic_clicked();

    void on_N_clicked();

    void on_V_clicked();

    void on_Voc_clicked();

    void on_Nesting_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
