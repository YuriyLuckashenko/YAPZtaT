//Task 1: create class User
//Task 2: create objects of class User